"""
keyboards/inline.py
───────────────────
Every inline keyboard the bot uses, in one place.
Callback data uses a simple prefix convention:
    section:action:param
"""

from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup
from config import REQUIRED_CHANNEL_LINK
from utils.helpers import btn_config


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  MANDATORY JOIN                                                     ║
# ╚══════════════════════════════════════════════════════════════════════╝

def join_channel_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton(**btn_config("join_channel", "Join Channel", "📢"), url=REQUIRED_CHANNEL_LINK),
        InlineKeyboardButton(**btn_config("check_join", "I've Joined", "✅", "success"), callback_data="check_join"),
    )
    return kb


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  MAIN MENU                                                         ║
# ╚══════════════════════════════════════════════════════════════════════╝

def main_menu_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(InlineKeyboardButton(**btn_config("menu_buy", "BUY", "🛒", "success"), callback_data="menu:buy"))
    kb.add(
        InlineKeyboardButton(**btn_config("menu_credits", "Add Funds", "💰", "primary"), callback_data="menu:wallet_add"),
        InlineKeyboardButton(**btn_config("menu_balance", "Balance", "💳"), callback_data="menu:balance"),
    )
    kb.add(
        InlineKeyboardButton(**btn_config("menu_profile", "Profile", "👤"), callback_data="menu:profile"),
        InlineKeyboardButton(**btn_config("menu_referral", "Refer/Earn", "🎁", "success"), callback_data="menu:referral"),
    )
    kb.add(
        InlineKeyboardButton(**btn_config("menu_orders", "Orders", "📜"), callback_data="menu:orders"),
        InlineKeyboardButton(**btn_config("menu_giftcode", "Redeem Gift Code", "🎟"), callback_data="menu:giftcode"),
    )
    kb.add(
        InlineKeyboardButton(**btn_config("menu_support", "Support", "📞"), callback_data="menu:support"),
        InlineKeyboardButton(**btn_config("menu_refresh", "Refresh", "🔄"), callback_data="menu:refresh"),
    )
    return kb


def back_to_menu_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("🔙 Back to Menu", callback_data="menu:main"))
    return kb


def referral_menu_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=1)
    # The actual "Copy Link" might be better implemented by formatting the link in the message as <code>,
    # but we can add a placeholder button or rely on Telegram's built in copy. Telegram inline buttons cannot "copy to clipboard".
    # I'll just use the standard layout requested.
    kb.add(InlineKeyboardButton("💸 Transfer to Wallet", callback_data="ref:transfer"))
    kb.add(InlineKeyboardButton("🔙 Back", callback_data="menu:main"))
    return kb


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  PRODUCTS / BUY PREMIUM                                            ║
# ╚══════════════════════════════════════════════════════════════════════╝

def products_list_kb(products: list[dict]) -> InlineKeyboardMarkup:
    """Generate a list of product buttons for the user."""
    kb = InlineKeyboardMarkup(row_width=1)
    from database import get_available_stock_count
    for p in products:
        stock = get_available_stock_count(str(p['_id']))
        
        btn_kwargs = btn_config(f"prod_btn_{p['_id']}", p['name'])
        # Re-attach the dynamic stock and price
        btn_kwargs['text'] = f"{btn_kwargs['text']} ({stock})  —  ${p.get('price_usd', 0.0):.2f}"
        btn_kwargs['callback_data'] = f"prod:view:{p['_id']}"
        
        # Override style based on stock availability
        if stock > 0:
            btn_kwargs['style'] = 'success'
        else:
            btn_kwargs['style'] = 'danger'
        
        kb.add(InlineKeyboardButton(**btn_kwargs))
    kb.add(InlineKeyboardButton("🔙 Back to Menu", callback_data="menu:main"))
    return kb


def product_detail_kb(product_id: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton(**btn_config("prod_buy", "Purchase", "🛒", "success"), callback_data=f"prod:buy:{product_id}"),
        InlineKeyboardButton(**btn_config("prod_back", "Back to Products", "🔙"), callback_data="menu:buy"),
    )
    return kb


def product_payment_method_kb(product_id: str, qty: int, price_usd: float) -> InlineKeyboardMarkup:
    from database import get_payment_settings
    settings = get_payment_settings()
    
    kb = InlineKeyboardMarkup(row_width=1)
    
    # Wallet Pay option
    kb.add(InlineKeyboardButton("💰 Pay via Wallet", callback_data=f"prod:confirm:wallet:{product_id}:{qty}"))
    
    # Direct Pay options
    buttons = []
    if settings.get("upi_enabled", True):
        buttons.append(InlineKeyboardButton("💳 Direct UPI", callback_data=f"prod:direct:upi:{product_id}:{qty}"))
    if settings.get("binance_enabled", True):
        buttons.append(InlineKeyboardButton("🪙 Direct Binance", callback_data=f"prod:direct:binance:{product_id}:{qty}"))
    if settings.get("bep20_enabled", True):
        buttons.append(InlineKeyboardButton("🔗 Direct BEP-20", callback_data=f"prod:direct:bep20:{product_id}:{qty}"))
        
    for i in range(0, len(buttons), 2):
        kb.add(*buttons[i:i+2])
        
    kb.add(InlineKeyboardButton(**btn_config("prod_cancel", "Cancel", "❌", "danger"), callback_data="menu:buy"))
    return kb

def confirm_purchase_kb(product_id: str, qty: int = 1) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(**btn_config("prod_confirm", "Confirm", "✅", "success"), callback_data=f"prod:confirm:{product_id}:{qty}"),
        InlineKeyboardButton(**btn_config("prod_cancel", "Cancel", "❌", "danger"), callback_data="menu:buy"),
    )
    return kb


def purchase_success_qr_kb(qr_order_id: str) -> InlineKeyboardMarkup:
    """Keyboard shown after successful purchase with Upload QR option."""
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton("📤 Upload QR", callback_data=f"qr:upload:{qr_order_id}"),
        InlineKeyboardButton("🔙 Back to Menu", callback_data="menu:main"),
    )
    return kb


def admin_qr_review_kb(qr_order_id: str) -> InlineKeyboardMarkup:
    """Admin keyboard for reviewing a QR upload."""
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton("✅ Payment Approved", callback_data=f"admqr:approve:{qr_order_id}"),
        InlineKeyboardButton("❌ Rejected / Refunded", callback_data=f"admqr:reject:{qr_order_id}"),
        InlineKeyboardButton("🔄 Reupload QR", callback_data=f"admqr:reupload:{qr_order_id}"),
    )
    return kb


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  WALLET PACKAGES                                                    ║
# ╚══════════════════════════════════════════════════════════════════════╝




def payment_method_kb(amount_usd: float) -> InlineKeyboardMarkup:
    from database import get_payment_settings
    settings = get_payment_settings()
    
    kb = InlineKeyboardMarkup(row_width=2)
    buttons = []
    if settings.get("upi_enabled", True):
        buttons.append(InlineKeyboardButton("💳 UPI", callback_data=f"pay:upi:{amount_usd}"))
    if settings.get("binance_enabled", True):
        buttons.append(InlineKeyboardButton("🪙 Binance (Recommended)", callback_data=f"pay:binance:{amount_usd}"))
    if settings.get("bep20_enabled", True):
        buttons.append(InlineKeyboardButton("🔗 BEP-20 (USDT)", callback_data=f"pay:bep20:{amount_usd}"))
    
    if buttons:
        kb.add(*buttons)
        
    kb.add(InlineKeyboardButton("🔙 Back", callback_data="menu:wallet_add"))
    return kb


def cancel_payment_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("❌ Cancel", callback_data="menu:main"))
    return kb


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  ADMIN – payment review                                            ║
# ╚══════════════════════════════════════════════════════════════════════╝

def admin_payment_review_kb(payment_id: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("✅ Approve", callback_data=f"admpay:approve:{payment_id}"),
        InlineKeyboardButton("❌ Reject", callback_data=f"admpay:reject:{payment_id}"),
    )
    return kb


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  ADMIN PANEL                                                        ║
# ╚══════════════════════════════════════════════════════════════════════╝

def admin_panel_kb(is_maintenance: bool = False, is_referral: bool = True) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("➕ Add Product", callback_data="adm:add_product"),
        InlineKeyboardButton("📋 Manage Products", callback_data="adm:manage_products"),
    )
    kb.add(
        InlineKeyboardButton("✅ Pending Payments", callback_data="adm:pending_payments"),
        InlineKeyboardButton("📦 Orders", callback_data="adm:orders"),
    )
    kb.add(
        InlineKeyboardButton("👥 Users", callback_data="adm:users"),
        InlineKeyboardButton("➕ Add Balance", callback_data="adm:add_balance"),
    )
    kb.add(
        InlineKeyboardButton("➖ Remove Balance", callback_data="adm:remove_balance"),
        InlineKeyboardButton("📢 Send Announcement", callback_data="adm:broadcast"),
    )
    kb.add(
        InlineKeyboardButton("🔎 Search Order", callback_data="adm:search_order"),
        InlineKeyboardButton("❌ Cancel Order", callback_data="adm:cancel_order"),
    )
    kb.add(
        InlineKeyboardButton("⚙️ Payment Settings", callback_data="adm:payment_settings"),
        InlineKeyboardButton("📊 Statistics", callback_data="adm:stats"),
    )
    kb.add(
        InlineKeyboardButton("🔍 Search Link/Code", callback_data="adm:search"),
        InlineKeyboardButton("🎨 UI Settings", callback_data="adm:ui_settings"),
    )
    kb.add(
        InlineKeyboardButton("📦 Delivery Settings", callback_data="adm:delivery_settings"),
        InlineKeyboardButton("📥 Global Bulk Import", callback_data="adm:bulk_import"),
    )
    
    maint_label = "🟢 Maintenance: ON" if is_maintenance else "🔴 Maintenance: OFF"
    kb.add(
        InlineKeyboardButton(maint_label, callback_data="adm:toggle_maintenance"),
        InlineKeyboardButton("🎁 Generate Gift Code", callback_data="adm:gen_gift_code"),
    )
    
    ref_label = "🟢 Referral: ON" if is_referral else "🔴 Referral: OFF"
    kb.add(
        InlineKeyboardButton(ref_label, callback_data="adm:toggle_referral"),
        InlineKeyboardButton("⚙️ Referral Settings", callback_data="adm:referral_settings"),
    )
    return kb


def payment_settings_kb() -> InlineKeyboardMarkup:
    from database import get_payment_settings
    settings = get_payment_settings()
    
    kb = InlineKeyboardMarkup(row_width=1)
    
    upi_status = "🟢 ON" if settings.get("upi_enabled", True) else "🔴 OFF"
    binance_status = "🟢 ON" if settings.get("binance_enabled", True) else "🔴 OFF"
    bep20_status = "🟢 ON" if settings.get("bep20_enabled", True) else "🔴 OFF"
    
    kb.add(
        InlineKeyboardButton(f"💳 UPI: {upi_status}", callback_data="admset:toggle_upi"),
        InlineKeyboardButton(f"🪙 Binance: {binance_status}", callback_data="admset:toggle_binance")
    )
    kb.add(
        InlineKeyboardButton(f"🔗 BEP-20: {bep20_status}", callback_data="admset:toggle_bep20")
    )
    kb.add(
        InlineKeyboardButton("💳 Edit UPI ID", callback_data="admset:upi_id"),
        InlineKeyboardButton("👤 Edit UPI Name", callback_data="admset:upi_name"),
    )
    kb.add(
        InlineKeyboardButton("🖼 Upload UPI QR", callback_data="admset:upload_upi_qr"),
    )
    kb.add(
        InlineKeyboardButton("🪙 Edit Binance UID", callback_data="admset:binance_uid"),
        InlineKeyboardButton("🔗 Edit BEP-20 Address", callback_data="admset:bep20_address"),
    )
    kb.add(
        InlineKeyboardButton("🖼 Upload BEP-20 QR", callback_data="admset:upload_bep20_qr"),
    )
    kb.add(InlineKeyboardButton("🔙 Admin Panel", callback_data="adm:panel"))
    return kb


def admin_delivery_settings_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton("📝 Edit Global Delivery Msg", callback_data="admset:del_global_msg"),
        InlineKeyboardButton("🎁 Edit Gift Code Output Msg", callback_data="admset:del_gift_code_msg"),
        InlineKeyboardButton("⏳ Edit Expiration Days", callback_data="admset:del_exp_days"),
        InlineKeyboardButton("⚠️ Edit Expiration Warning", callback_data="admset:del_exp_warn"),
        InlineKeyboardButton("🔙 Admin Panel", callback_data="adm:panel")
    )
    return kb


def admin_user_actions_kb(user_id: int, is_banned: bool) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=2)
    
    # Ban / Unban
    if is_banned:
        kb.add(InlineKeyboardButton("✅ Unban User", callback_data=f"admuser:unban:{user_id}"))
    else:
        kb.add(InlineKeyboardButton("🚫 Ban (Mute) User", callback_data=f"admuser:ban:{user_id}"))
        
    kb.add(
        InlineKeyboardButton("✉️ Send Message", callback_data=f"admuser:msg:{user_id}"),
        InlineKeyboardButton("🗑️ Delete User", callback_data=f"admuser:delete:{user_id}")
    )
    kb.add(
        InlineKeyboardButton("🔄 Convert Points", callback_data=f"admuser:convert:{user_id}"),
        InlineKeyboardButton("📦 View Orders", callback_data=f"admuser:orders:{user_id}")
    )
    kb.add(InlineKeyboardButton("🔙 Back to Search", callback_data="adm:users"))
    return kb


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  ADMIN UI SETTINGS                                                   ║
# ╚══════════════════════════════════════════════════════════════════════╝

def admin_ui_button_list_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=1)
    buttons_to_edit = [
        ("menu_buy", "Main Menu: BUY"),
        ("menu_credits", "Main Menu: Add Funds"),
        ("menu_balance", "Main Menu: Balance"),
        ("menu_profile", "Main Menu: Profile"),
        ("menu_referral", "Main Menu: Refer/Earn"),
        ("menu_orders", "Main Menu: Orders"),
        ("menu_giftcode", "Main Menu: Gift Code"),
        ("menu_support", "Main Menu: Support"),
        ("join_channel", "Join Channel: Link"),
        ("check_join", "Join Channel: I've Joined"),
        ("prod_buy", "Product detail: Purchase"),
        ("prod_confirm", "Product confirm: Confirm"),
        ("prod_cancel", "Product confirm: Cancel"),
    ]
    for key, label in buttons_to_edit:
        kb.add(InlineKeyboardButton(f"🎨 {label}", callback_data=f"admui:edit:{key}"))
        
    from database import get_all_products
    products = get_all_products()
    for p in products:
        kb.add(InlineKeyboardButton(f"🎨 Product List: {p['name']}", callback_data=f"admui:edit:prod_btn_{p['_id']}"))
        
    kb.add(InlineKeyboardButton("🔙 Admin Panel", callback_data="adm:panel"))
    return kb


def admin_ui_edit_kb(button_key: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=1)
    if not button_key.startswith("prod_btn_"):
        kb.add(InlineKeyboardButton("✏️ Edit Text", callback_data=f"admui:settext:{button_key}"))
    kb.add(InlineKeyboardButton("🎨 Edit Color Style", callback_data=f"admui:style:{button_key}"))
    kb.add(InlineKeyboardButton("✨ Edit Custom Emoji ID", callback_data=f"admui:setemoji:{button_key}"))
    kb.add(InlineKeyboardButton("🗑️ Remove Emoji", callback_data=f"admui:rmemoji:{button_key}"))
    kb.add(InlineKeyboardButton("🔙 Back to UI List", callback_data="adm:ui_settings"))
    return kb


def admin_ui_style_kb(button_key: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("🟦 Primary (Blue)", callback_data=f"admui:setstyle:{button_key}:primary"),
        InlineKeyboardButton("🟩 Success (Green)", callback_data=f"admui:setstyle:{button_key}:success"),
        InlineKeyboardButton("🟥 Danger (Red)", callback_data=f"admui:setstyle:{button_key}:danger"),
        InlineKeyboardButton("⬛ Default (Clear)", callback_data=f"admui:setstyle:{button_key}:none"),
    )
    kb.add(InlineKeyboardButton("🔙 Back", callback_data=f"admui:edit:{button_key}"))
    return kb





def referral_settings_kb(ref_config: dict, is_conversion_on: bool = True, is_welcome_bonus_on: bool = True) -> InlineKeyboardMarkup:
    """Keyboard for editing referral conversion settings."""
    kb = InlineKeyboardMarkup(row_width=1)
    
    welcome_label = "🟢 Welcome Bonus: ON" if is_welcome_bonus_on else "🔴 Welcome Bonus: OFF"
    kb.add(
        InlineKeyboardButton(welcome_label, callback_data="adm:toggle_welcome_bonus"),
    )
    kb.add(
        InlineKeyboardButton(
            f"📈 Commission: {ref_config['commission_percent']}%",
            callback_data="admset:referral_commission",
        ),
        InlineKeyboardButton(
            f"🎁 1st Purchase Bonus: ${ref_config['first_purchase_bonus']}",
            callback_data="admset:referral_first_bonus",
        ),
        InlineKeyboardButton(
            f"💸 Min Transfer: ${ref_config['min_transfer']}",
            callback_data="admset:referral_min_transfer",
        ),
    )
    kb.add(InlineKeyboardButton("🔙 Admin Panel", callback_data="adm:panel"))
    return kb


def admin_back_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("🔙 Admin Panel", callback_data="adm:panel"))
    return kb


def gift_code_actions_kb(code: str) -> InlineKeyboardMarkup:
    """Keyboard shown after generating a gift code with send options."""
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton("📢 Send to All Users", callback_data=f"admgift:broadcast:{code}"),
        InlineKeyboardButton("📨 Send Privately", callback_data=f"admgift:private:{code}"),
        InlineKeyboardButton("🔙 Admin Panel", callback_data="adm:panel"),
    )
    return kb


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  ADMIN – product management                                        ║
# ╚══════════════════════════════════════════════════════════════════════╝

def admin_products_list_kb(products: list[dict]) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=1)
    for p in products:
        status = "✅" if p.get("active") else "❌"
        kb.add(InlineKeyboardButton(
            f"{status} {p['name']}",
            callback_data=f"admprod:view:{p['_id']}",
        ))
    kb.add(InlineKeyboardButton("🔙 Admin Panel", callback_data="adm:panel"))
    return kb


def admin_product_actions_kb(product_id: str, is_active: bool, is_numerical: bool = False, requires_qr: bool = False, bulk_enabled: bool = False) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(row_width=2)
    toggle_label = "🔴 Disable" if is_active else "🟢 Enable"
    toggle_cb = f"admprod:toggle:{product_id}"
    qr_label = "🔴 QR Upload: OFF" if not requires_qr else "🟢 QR Upload: ON"
    
    kb.add(
        InlineKeyboardButton("📝 Edit Name", callback_data=f"admprod:edit_name:{product_id}"),
        InlineKeyboardButton("📝 Edit Desc", callback_data=f"admprod:edit_desc:{product_id}"),
    )
    
    # Stock and switch toggle
    if is_numerical:
        kb.add(
            InlineKeyboardButton("💰 Edit Cost", callback_data=f"admprod:edit_cost:{product_id}"),
            InlineKeyboardButton("✏️ Set Stock Limit", callback_data=f"admprod:set_num_stock:{product_id}"),
        )
        kb.add(InlineKeyboardButton("🔁 Switch to Links", callback_data=f"admprod:toggle_numerical:{product_id}"))
    else:
        kb.add(
            InlineKeyboardButton("💰 Edit Cost", callback_data=f"admprod:edit_cost:{product_id}"),
            InlineKeyboardButton("📦 Add Stock", callback_data=f"admprod:addstock:{product_id}"),
        )
        kb.add(
            InlineKeyboardButton("📦 Add Stock (Allow Dups)", callback_data=f"admprod:addstock_dup:{product_id}")
        )
        kb.add(InlineKeyboardButton("🔁 Switch to Numerical", callback_data=f"admprod:toggle_numerical:{product_id}"))
        
    kb.add(
        InlineKeyboardButton(toggle_label, callback_data=toggle_cb),
        InlineKeyboardButton("🗑 Delete", callback_data=f"admprod:delete:{product_id}"),
    )
    kb.add(
        InlineKeyboardButton(qr_label, callback_data=f"admprod:toggle_qr:{product_id}"),
        InlineKeyboardButton("📝 Edit Delivery Msg", callback_data=f"admprod:edit_delmsg:{product_id}")
    )
    kb.add(
        InlineKeyboardButton("⏳ Edit Expire Days", callback_data=f"admprod:edit_expdays:{product_id}")
    )
    
    bulk_label = "🟢 Bulk Discounts: ON" if bulk_enabled else "🔴 Bulk Discounts: OFF"
    kb.add(
        InlineKeyboardButton(bulk_label, callback_data=f"admprod:toggle_bulk:{product_id}"),
        InlineKeyboardButton("📝 Edit Bulk Tiers", callback_data=f"admprod:edit_bulk:{product_id}"),
    )
    
    kb.add(InlineKeyboardButton("🔙 Back", callback_data="adm:manage_products"))
    return kb

def admin_stock_type_kb() -> InlineKeyboardMarkup:
    """Keyboard for selecting stock type during product creation."""
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton("🔗 Links / Coupons", callback_data="admprod:stock_type:links"),
        InlineKeyboardButton("🔢 Numerical Service", callback_data="admprod:stock_type:numerical"),
        InlineKeyboardButton("🔙 Cancel", callback_data="adm:panel")
    )
    return kb

def bulk_stock_upload_kb() -> InlineKeyboardMarkup:
    """Keyboard for global bulk stock upload state."""
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("✅ Process Uploads", callback_data="adm:bulk_process"),
        InlineKeyboardButton("❌ Cancel", callback_data="adm:bulk_cancel")
    )
    return kb

def bulk_stock_confirm_kb() -> InlineKeyboardMarkup:
    """Keyboard to confirm bulk stock updates after review."""
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("✅ Confirm Updates", callback_data="adm:bulk_confirm"),
        InlineKeyboardButton("❌ Cancel", callback_data="adm:bulk_cancel")
    )
    return kb

def gift_code_type_kb() -> InlineKeyboardMarkup:
    """Keyboard for selecting gift code reward type."""
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("💰 Points", callback_data="admgift:type:points"),
        InlineKeyboardButton("🔗 Link / Coupon", callback_data="admgift:type:link")
    )
    kb.add(InlineKeyboardButton("🔙 Cancel", callback_data="adm:panel"))
    return kb
