"""
database.py
───────────
MongoDB connection helper and collection accessors.
Creates indexes on first import so queries stay fast.
"""

from datetime import datetime, timezone, timedelta
from pymongo import MongoClient, ASCENDING, DESCENDING
from config import MONGO_URI, DB_NAME, logger

# ── Connection ───────────────────────────────────────────────────────────
client = MongoClient(MONGO_URI)
db = client[DB_NAME]

# ── Collections ──────────────────────────────────────────────────────────
users_col = db["users"]
products_col = db["products"]
payments_col = db["payments"]
orders_col = db["orders"]
stock_col = db["stock"]
settings_col = db["settings"]
gift_codes_col = db["gift_codes"]
qr_orders_col = db["qr_orders"]


# ── Indexes (idempotent – safe to call on every startup) ─────────────────
def ensure_indexes() -> None:
    """Create MongoDB indexes for fast lookups."""
    users_col.create_index([("user_id", ASCENDING)], unique=True)
    users_col.create_index([("referral_code", ASCENDING)], unique=True)

    products_col.create_index([("active", ASCENDING)])
    products_col.create_index([("created_at", DESCENDING)])

    payments_col.create_index([("user_id", ASCENDING)])
    payments_col.create_index([("status", ASCENDING)])
    payments_col.create_index([("created_at", DESCENDING)])

    orders_col.create_index([("user_id", ASCENDING)])
    orders_col.create_index([("created_at", DESCENDING)])

    stock_col.create_index([("product_id", ASCENDING), ("is_sold", ASCENDING)])
    stock_col.create_index([("product_id", ASCENDING)])
    try:
        stock_col.drop_index("content_1")
    except Exception:
        pass
    stock_col.create_index([("content", ASCENDING)], sparse=True)

    gift_codes_col.create_index([("code", ASCENDING)], unique=True)

    qr_orders_col.create_index([("user_id", ASCENDING)])
    qr_orders_col.create_index([("status", ASCENDING)])
    qr_orders_col.create_index([("created_at", DESCENDING)])

    logger.info("MongoDB indexes ensured.")


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  USER helpers                                                       ║
# ╚══════════════════════════════════════════════════════════════════════╝

def get_user(user_id: int) -> dict | None:
    return users_col.find_one({"user_id": user_id})


def register_user(user_id: int, username: str, first_name: str,
                   referral_code: str, referred_by: str | None = None) -> dict:
    """Insert a new user document. Returns the inserted doc."""
    doc = {
        "user_id": user_id,
        "username": username or "",
        "first_name": first_name or "",
        "wallet_balance": 0.0,
        "referral_code": referral_code,
        "referred_by": referred_by,
        "referral_count": 0,
        "referral_points": 1 if is_welcome_bonus_enabled() else 0,
        "free_referral_bonus": 0.0,
        "joined_at": datetime.now(timezone.utc),
    }
    users_col.insert_one(doc)
    return doc


def update_user(user_id: int, update: dict) -> None:
    users_col.update_one({"user_id": user_id}, update)


def add_balance(user_id: int, amount: float) -> None:
    users_col.update_one({"user_id": user_id}, {"$inc": {"wallet_balance": float(amount)}})


def remove_balance(user_id: int, amount: float) -> None:
    users_col.update_one({"user_id": user_id}, {"$inc": {"wallet_balance": -float(amount)}})


def increment_referral_count(user_id: int) -> dict | None:
    """Increment referral_count and points, return the updated document."""
    return users_col.find_one_and_update(
        {"user_id": user_id},
        {"$inc": {"referral_count": 1, "referral_points": 1}},
        return_document=True,
    )


def redeem_referral_points(user_id: int, points_cost: int, bonus_usd: float) -> bool:
    """
    Legacy points-to-credits conversion function. Keeping for backwards compatibility if needed.
    """
    result = users_col.update_one(
        {"user_id": user_id, "referral_points": {"$gte": points_cost}},
        {"$inc": {"wallet_balance": bonus_usd, "free_referral_bonus": bonus_usd, "referral_points": -points_cost}},
    )
    return result.modified_count > 0


def get_referral_stats(referral_code: str) -> dict:
    """Calculate referrals for 24h, 7d, and total."""
    now = datetime.now(timezone.utc)
    day_ago = now - timedelta(days=1)
    week_ago = now - timedelta(days=7)
    
    total = users_col.count_documents({"referred_by": referral_code})
    last_24h = users_col.count_documents({"referred_by": referral_code, "joined_at": {"$gte": day_ago}})
    last_7d = users_col.count_documents({"referred_by": referral_code, "joined_at": {"$gte": week_ago}})
    
    return {"total": total, "24h": last_24h, "7d": last_7d}


def process_referral_commission(user_id: int, amount_usd: float) -> None:
    """
    Give the referrer a % of the deposit/purchase, plus a fixed bonus on the first purchase.
    """
    user = get_user(user_id)
    if not user or not user.get("referred_by"):
        return
        
    referrer = get_user_by_referral_code(user["referred_by"])
    if not referrer:
        return
        
    ref_config = get_referral_config()
    commission_pct = ref_config.get("commission_percent", 2.0)
    first_purchase_bonus = ref_config.get("first_purchase_bonus", 0.10)
    
    commission = amount_usd * (commission_pct / 100.0)
    
    bonus_amount = 0.0
    if not user.get("first_purchase_bonus_given"):
        bonus_amount = first_purchase_bonus
        update_user(user_id, {"$set": {"first_purchase_bonus_given": True}})
        
    total_commission = commission + bonus_amount
    if total_commission <= 0:
        return
    
    update_user(referrer["user_id"], {
        "$inc": {
            "referral_earned_usdt": total_commission,
            "referral_available_usdt": total_commission
        }
    })


def transfer_referral_commission(user_id: int, amount: float) -> bool:
    """Atomically deduct from available and add to wallet."""
    result = users_col.update_one(
        {"user_id": user_id, "referral_available_usdt": {"$gte": amount}},
        {
            "$inc": {
                "referral_available_usdt": -amount,
                "referral_transferred_usdt": amount,
                "wallet_balance": amount
            }
        }
    )
    return result.modified_count > 0


def get_all_user_ids() -> list[int]:
    """Return list of all user_ids (for broadcasts)."""
    return [u["user_id"] for u in users_col.find({}, {"user_id": 1})]


def get_user_by_referral_code(code: str) -> dict | None:
    return users_col.find_one({"referral_code": code})


def count_users() -> int:
    return users_col.count_documents({})


def search_user_by_id(user_id: int) -> dict | None:
    return get_user(user_id)


def ban_user(user_id: int, ban: bool) -> None:
    """Ban or unban a user by setting is_banned."""
    users_col.update_one({"user_id": user_id}, {"$set": {"is_banned": ban}})


def delete_user(user_id: int) -> None:
    """Delete a user permanently."""
    users_col.delete_one({"user_id": user_id})


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  PRODUCT helpers                                                    ║
# ╚══════════════════════════════════════════════════════════════════════╝

def create_product(name: str, description: str, price_usd: float, is_numerical: bool = False, numerical_stock: int = 0, requires_qr: bool = False) -> str:
    """Insert a product and return its _id as string."""
    doc = {
        "name": name,
        "description": description,
        "price_usd": float(price_usd),
        "active": True,
        "is_numerical": is_numerical,
        "numerical_stock": numerical_stock,
        "requires_qr": requires_qr,
        "delivery_message": "",
        "bulk_discount_enabled": False,
        "bulk_discount_text": "",
        "created_at": datetime.now(timezone.utc),
    }
    result = products_col.insert_one(doc)
    return str(result.inserted_id)


def get_active_products() -> list[dict]:
    return list(products_col.find({"active": True}).sort("created_at", DESCENDING))


def get_product(product_id) -> dict | None:
    from bson import ObjectId
    return products_col.find_one({"_id": ObjectId(product_id)})


def get_all_products() -> list[dict]:
    return list(products_col.find().sort("created_at", DESCENDING))


def update_product(product_id, update: dict) -> None:
    from bson import ObjectId
    products_col.update_one({"_id": ObjectId(product_id)}, update)


def delete_product(product_id) -> None:
    from bson import ObjectId
    products_col.delete_one({"_id": ObjectId(product_id)})


def count_products() -> int:
    return products_col.count_documents({"active": True})


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  STOCK / INVENTORY helpers                                          ║
# ╚══════════════════════════════════════════════════════════════════════╝

def get_existing_stock_links(links: list[str]) -> set[str]:
    """Return a set of links that already exist in stock (any product, sold or unsold)."""
    stripped = [l.strip() for l in links if l.strip()]
    if not stripped:
        return set()
    existing_docs = stock_col.find({"content": {"$in": stripped}}, {"content": 1})
    return {doc["content"] for doc in existing_docs}


def add_stock_items(product_id: str, links: list[str], allow_duplicates: bool = False) -> tuple[int, int]:
    """
    Bulk-insert stock items for a product, optionally skipping duplicates.
    Returns (count_inserted, count_duplicates).
    """
    from bson import ObjectId
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    
    product = products_col.find_one({"_id": ObjectId(product_id)})
    if product and "expiration_days" in product:
        exp_days = product["expiration_days"]
    else:
        del_settings = get_delivery_settings()
        exp_days = del_settings.get("expiration_days", 7)
        
    expires_at = now + timedelta(days=exp_days)

    # Filter out links that already exist in any product's stock
    stripped_links = [link.strip() for link in links if link.strip()]
    
    unique_links = []
    seen = set()
    in_batch_dups = 0
    for link in stripped_links:
        if link in seen:
            in_batch_dups += 1
        else:
            seen.add(link)
            unique_links.append(link)

    if allow_duplicates:
        new_links = stripped_links
        duplicate_count = 0
    else:
        existing = get_existing_stock_links(unique_links)
        new_links = [l for l in unique_links if l not in existing]
        duplicate_count = in_batch_dups + (len(unique_links) - len(new_links))

    docs = [
        {
            "product_id": ObjectId(product_id),
            "content": link,
            "is_sold": False,
            "sold_to": None,
            "sold_at": None,
            "added_at": now,
            "expires_at": expires_at,
        }
        for link in new_links
    ]
    if not docs:
        return 0, duplicate_count
    result = stock_col.insert_many(docs)
    return len(result.inserted_ids), duplicate_count


def get_available_stock_count(product_id: str) -> int:
    """Count unsold stock items for a product, or return numerical stock if applicable."""
    from bson import ObjectId
    product = products_col.find_one({"_id": ObjectId(product_id)})
    if product and product.get("is_numerical"):
        return product.get("numerical_stock", 0)

    return stock_col.count_documents({
        "product_id": ObjectId(product_id),
        "is_sold": False,
    })


def get_total_stock_count(product_id: str) -> int:
    """Count all stock items (sold + unsold) for a product."""
    from bson import ObjectId
    return stock_col.count_documents({"product_id": ObjectId(product_id)})


def claim_stock_item(product_id: str, user_id: int) -> dict | None:
    """
    Atomically claim one unsold stock item for a user.
    Returns the stock document (with content) or None if out of stock.
    """
    from bson import ObjectId
    return stock_col.find_one_and_update(
        {"product_id": ObjectId(product_id), "is_sold": False},
        {"$set": {"is_sold": True, "sold_to": user_id, "sold_at": datetime.now(timezone.utc)}},
    )


def delete_product_stock(product_id: str) -> int:
    """Delete all stock items for a product. Returns count deleted."""
    from bson import ObjectId
    result = stock_col.delete_many({"product_id": ObjectId(product_id)})
    return result.deleted_count


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  PAYMENT helpers                                                    ║
# ╚══════════════════════════════════════════════════════════════════════╝

def create_payment(user_id: int, username: str, method: str, amount_usd: float,
                   intent: str = "add_to_wallet", product_id: str | None = None,
                   utr_number: str | None = None, binance_order_id: str | None = None, qty: int = 1) -> str:
    """Insert a payment request. Returns the _id as string."""
    doc = {
        "user_id": user_id,
        "username": username or "",
        "method": method,
        "amount_usd": amount_usd,
        "intent": intent,
        "product_id": product_id,
        "qty": qty,
        "utr_number": utr_number,
        "binance_order_id": binance_order_id,
        "status": "pending",
        "created_at": datetime.now(timezone.utc),
        "reviewed_at": None,
    }
    result = payments_col.insert_one(doc)
    return str(result.inserted_id)


def check_binance_order_exists(binance_order_id: str) -> bool:
    """Check if a Binance Order ID has already been submitted."""
    return payments_col.count_documents({"binance_order_id": binance_order_id}) > 0


def get_pending_payments() -> list[dict]:
    return list(payments_col.find({"status": "pending"}).sort("created_at", ASCENDING))


def approve_payment(payment_id) -> dict | None:
    from bson import ObjectId
    return payments_col.find_one_and_update(
        {"_id": ObjectId(payment_id), "status": "pending"},
        {"$set": {"status": "approved", "reviewed_at": datetime.now(timezone.utc)}},
        return_document=True,
    )


def reject_payment(payment_id) -> dict | None:
    from bson import ObjectId
    return payments_col.find_one_and_update(
        {"_id": ObjectId(payment_id), "status": "pending"},
        {"$set": {"status": "rejected", "reviewed_at": datetime.now(timezone.utc)}},
        return_document=True,
    )


def count_payments() -> int:
    return payments_col.count_documents({})


def total_credits_sold() -> int:
    """Sum of credits from all approved payments."""
    pipeline = [
        {"$match": {"status": "approved"}},
        {"$group": {"_id": None, "total": {"$sum": "$credits"}}},
    ]
    result = list(payments_col.aggregate(pipeline))
    return result[0]["total"] if result else 0


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  ORDER helpers                                                      ║
# ╚══════════════════════════════════════════════════════════════════════╝

def create_order(user_id: int, product_name: str, credits_used: int, items: list[str] = None) -> str:
    doc = {
        "user_id": user_id,
        "product_name": product_name,
        "credits_used": credits_used,
        "items": items or [],
        "created_at": datetime.now(timezone.utc),
    }
    result = orders_col.insert_one(doc)
    return str(result.inserted_id)


def get_user_orders(user_id: int) -> list[dict]:
    return list(orders_col.find({"user_id": user_id}).sort("created_at", DESCENDING))


def count_orders() -> int:
    return orders_col.count_documents({})


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  SETTINGS helpers (runtime-editable config)                          ║
# ╚══════════════════════════════════════════════════════════════════════╝

def get_setting(key: str, default: str = "") -> str:
    """Get a setting value from DB. Falls back to *default* if not set."""
    doc = settings_col.find_one({"key": key})
    if doc:
        return doc.get("value", default)
    return default


def set_setting(key: str, value: str) -> None:
    """Upsert a setting value in DB."""
    settings_col.update_one(
        {"key": key},
        {"$set": {"key": key, "value": value}},
        upsert=True,
    )


def get_payment_settings() -> dict:
    doc = settings_col.find_one({"_id": "payment_settings"}) or {}
    from config import UPI_ID, UPI_NAME, BINANCE_UID, BEP20_ADDRESS, TRC20_ADDRESS
    return {
        "upi_id": get_setting("upi_id", UPI_ID),
        "upi_name": get_setting("upi_name", UPI_NAME),
        "binance_uid": get_setting("binance_uid", BINANCE_UID),
        "bep20_address": get_setting("bep20_address", BEP20_ADDRESS),
        "trc20_address": get_setting("trc20_address", TRC20_ADDRESS),
        "upi_enabled": doc.get("upi_enabled", True),
        "binance_enabled": doc.get("binance_enabled", True),
        "bep20_enabled": doc.get("bep20_enabled", True),
        "trc20_enabled": doc.get("trc20_enabled", True),
        "bep20_qr_enabled": doc.get("bep20_qr_enabled", True),
        "trc20_qr_enabled": doc.get("trc20_qr_enabled", True)
    }


def update_payment_settings(upi_id: str, upi_name: str, binance_uid: str, bep20_address: str, trc20_address: str) -> None:
    settings_col.update_one(
        {"_id": "payment_settings"},
        {"$set": {"upi_enabled": True, "binance_enabled": True, "bep20_enabled": True, "trc20_enabled": True}},
        upsert=True
    )
    set_setting("upi_id", upi_id)
    set_setting("upi_name", upi_name)
    set_setting("binance_uid", binance_uid)
    set_setting("bep20_address", bep20_address)
    set_setting("trc20_address", trc20_address)


def get_delivery_settings() -> dict:
    """Get delivery settings like expiration days and messages."""
    doc = settings_col.find_one({"_id": "delivery_settings"}) or {}
    return {
        "global_message": doc.get("global_message", "Thank you for your purchase! 🎉"),
        "expiration_days": doc.get("expiration_days", 7),
        "expiration_warning": doc.get("expiration_warning", "⚠️ <i>Use these links within {days} days before they expire.</i>"),
        "gift_code_broadcast_msg": doc.get("gift_code_broadcast_msg", 
            "🎉 <b>YOUR EXCLUSIVE GIFT CODE IS READY!</b> 🎁\n\n"
            "🎟 <code>{code}</code>\n"
            "📋 Tap to Copy\n\n"
            "{reward_display}"
            "⏳ Expires in {expiry_str}\n"
            "⚡ Redeem fast  !!!  before it disappears 🚀"
        )
    }

def update_delivery_settings(update_data: dict) -> None:
    """Update delivery settings."""
    settings_col.update_one(
        {"_id": "delivery_settings"},
        {"$set": update_data},
        upsert=True
    )


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  MAINTENANCE MODE helpers                                            ║
# ╚══════════════════════════════════════════════════════════════════════╝

def is_maintenance_mode() -> bool:
    doc = settings_col.find_one({"_id": "maintenance_mode"})
    return doc.get("enabled", False) if doc else False


def set_maintenance_mode(enabled: bool) -> None:
    settings_col.update_one(
        {"_id": "maintenance_mode"},
        {"$set": {"enabled": enabled}},
        upsert=True
    )


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  REFERRAL PROGRAM helpers                                            ║
# ╚══════════════════════════════════════════════════════════════════════╝

def is_referral_enabled() -> bool:
    """Check if the referral program is enabled. Defaults to True."""
    doc = settings_col.find_one({"_id": "referral_program"})
    return doc.get("enabled", True) if doc else True


def set_referral_enabled(enabled: bool) -> None:
    """Enable or disable the referral program."""
    settings_col.update_one(
        {"_id": "referral_program"},
        {"$set": {"enabled": enabled}},
        upsert=True
    )


def get_referral_config() -> dict:
    """
    Get new USDT referral config from DB.
    Returns: {"commission_percent": float, "first_purchase_bonus": float, "min_transfer": float}
    """
    doc = settings_col.find_one({"_id": "referral_config"})
    if doc:
        return {
            "commission_percent": doc.get("commission_percent", 2.0),
            "first_purchase_bonus": doc.get("first_purchase_bonus", 0.10),
            "min_transfer": doc.get("min_transfer", 2.00)
        }
    return {
        "commission_percent": 2.0,
        "first_purchase_bonus": 0.10,
        "min_transfer": 2.00
    }


def set_referral_config(commission_percent: float = None, first_purchase_bonus: float = None, min_transfer: float = None) -> None:
    """Update new referral config. Only updates provided fields."""
    update = {}
    if commission_percent is not None:
        update["commission_percent"] = commission_percent
    if first_purchase_bonus is not None:
        update["first_purchase_bonus"] = first_purchase_bonus
    if min_transfer is not None:
        update["min_transfer"] = min_transfer
        
    if update:
        settings_col.update_one(
            {"_id": "referral_config"},
            {"$set": update},
            upsert=True
        )


def is_credit_conversion_enabled() -> bool:
    """Check if points-to-credits conversion is enabled. Defaults to True."""
    doc = settings_col.find_one({"_id": "credit_conversion"})
    return doc.get("enabled", True) if doc else True


def set_credit_conversion_enabled(enabled: bool) -> None:
    """Enable or disable points-to-credits conversion."""
    settings_col.update_one(
        {"_id": "credit_conversion"},
        {"$set": {"enabled": enabled}},
        upsert=True
    )


def is_welcome_bonus_enabled() -> bool:
    """Check if the welcome bonus (1 point on registration) is enabled. Defaults to True."""
    doc = settings_col.find_one({"_id": "welcome_bonus"})
    return doc.get("enabled", True) if doc else True


def set_welcome_bonus_enabled(enabled: bool) -> None:
    """Enable or disable the welcome bonus."""
    settings_col.update_one(
        {"_id": "welcome_bonus"},
        {"$set": {"enabled": enabled}},
        upsert=True
    )


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  GIFT CODES helpers                                                  ║
# ╚══════════════════════════════════════════════════════════════════════╝

def create_gift_code(code: str, points_value: int, max_uses: int, expires_at: datetime | None, created_by: int, reward_type: str = "points", reward_content: str = "", delivery_message: str = "") -> None:
    """Creates a new gift code that gives points or a link/coupon."""
    doc = {
        "code": code,
        "points": points_value,
        "reward_type": reward_type,
        "reward_content": reward_content,
        "delivery_message": delivery_message,
        "max_uses": max_uses,
        "current_uses": 0,
        "expires_at": expires_at,
        "created_by": created_by,
        "created_at": datetime.now(timezone.utc),
        "redeemed_by": []  # List of user_ids who have redeemed it
    }
    gift_codes_col.insert_one(doc)


def get_gift_code(code: str) -> dict | None:
    """Retrieve a gift code by its code string."""
    return gift_codes_col.find_one({"code": code})


def redeem_gift_code(code: str, user_id: int) -> tuple[bool, dict | str]:
    """
    Attempts to redeem a gift code for a user.
    Returns (True, dict) if successful. Returns (False, error string) if it fails.
    Gift codes give points (referral_points) or a link.
    """
    code_doc = gift_codes_col.find_one({"code": code})
    if not code_doc:
        return False, "Invalid code."
        
    if code_doc["current_uses"] >= code_doc["max_uses"]:
        return False, "This code has reached its maximum usage limit."
        
    if code_doc["expires_at"] and datetime.now(timezone.utc) > code_doc["expires_at"].replace(tzinfo=timezone.utc):
        return False, "This code has expired."
        
    if user_id in code_doc.get("redeemed_by", []):
        return False, "You have already redeemed this code."
        
    # Atomically update usage
    result = gift_codes_col.update_one(
        {"_id": code_doc["_id"], "current_uses": {"$lt": code_doc["max_uses"]}},
        {
            "$inc": {"current_uses": 1},
            "$push": {"redeemed_by": user_id}
        }
    )
    
    if result.modified_count == 1:
        reward_type = code_doc.get("reward_type", "points")
        delivery_msg = code_doc.get("delivery_message", "")
        if reward_type == "points":
            # Give points (referral_points), not credits
            users_col.update_one(
                {"user_id": user_id},
                {"$inc": {"referral_points": code_doc["points"]}}
            )
            return True, {"type": "points", "value": code_doc["points"], "delivery_message": delivery_msg}
        else:
            return True, {"type": "link", "value": code_doc.get("reward_content", ""), "delivery_message": delivery_msg}
        
    return False, "Failed to redeem code. Please try again."

def search_database(query: str) -> dict:
    """Search for a link in stock_col or a code in gift_codes_col."""
    query = query.strip()
    result = {"type": "none", "data": None}
    
    # Check if query is a URL with a coupon
    search_term = query
    try:
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(query)
        if parsed.query:
            params = parse_qs(parsed.query)
            if "coupon" in params and params["coupon"]:
                search_term = params["coupon"][0].strip()
    except Exception:
        pass
    
    # 1. Search in stock
    stock_item = stock_col.find_one({"content": {"$regex": search_term, "$options": "i"}})
    if stock_item:
        result["type"] = "stock"
        result["data"] = stock_item
        return result
        
    # 2. Search in gift codes
    code_item = gift_codes_col.find_one({"code": query})
    if code_item:
        result["type"] = "gift_code"
        result["data"] = code_item
        return result
        
    return result

def update_ui_setting(button_key: str, field: str, value: str):
    """
    Update a specific field (text, style, emoji_id) for a button in the ui_buttons setting.
    """
    ui_settings = get_setting("ui_buttons", {})
    if button_key not in ui_settings:
        ui_settings[button_key] = {}
    
    ui_settings[button_key][field] = value
    
    # Save back to settings_col
    settings_col.update_one(
        {"key": "ui_buttons"},
        {"$set": {"key": "ui_buttons", "value": ui_settings}},
        upsert=True
    )


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  QR ORDER helpers                                                    ║
# ╚══════════════════════════════════════════════════════════════════════╝

def create_qr_order(user_id: int, product_name: str, credits_used: int,
                    items: list[str], order_id: str, product_id: str = None, 
                    qty: int = 1, is_numerical: bool = False) -> str:
    """Create a QR order record after purchase. Returns the _id as string."""
    doc = {
        "user_id": user_id,
        "product_id": product_id,
        "product_name": product_name,
        "credits_used": credits_used,
        "qty": qty,
        "is_numerical": is_numerical,
        "items": items or [],
        "order_id": order_id,
        "status": "awaiting_qr",  # awaiting_qr → qr_uploaded → approved/rejected/reupload
        "qr_file_id": None,
        "qr_file_unique_id": None,
        "uploaded_qr_ids": [],  # track all uploaded QR unique IDs to prevent duplicates
        "created_at": datetime.now(timezone.utc),
        "updated_at": None,
    }
    result = qr_orders_col.insert_one(doc)
    return str(result.inserted_id)


def get_qr_order(qr_order_id: str) -> dict | None:
    """Fetch a QR order by its _id."""
    from bson import ObjectId
    return qr_orders_col.find_one({"_id": ObjectId(qr_order_id)})


def update_qr_order_status(qr_order_id: str, status: str,
                           qr_file_id: str = None,
                           qr_file_unique_id: str = None) -> None:
    """Update a QR order's status and optionally its QR file info."""
    from bson import ObjectId
    update = {
        "$set": {
            "status": status,
            "updated_at": datetime.now(timezone.utc),
        }
    }
    if qr_file_id is not None:
        update["$set"]["qr_file_id"] = qr_file_id
        update["$set"]["qr_file_unique_id"] = qr_file_unique_id
    if qr_file_unique_id is not None:
        update.setdefault("$push", {})
        update["$push"]["uploaded_qr_ids"] = qr_file_unique_id
    qr_orders_col.update_one({"_id": ObjectId(qr_order_id)}, update)


def check_duplicate_qr(user_id: int, file_unique_id: str) -> bool:
    """Check if the exact same QR code was previously uploaded by this user."""
    # We check if the file_unique_id exists in *any* of the user's qr_orders' uploaded_qr_ids
    existing = qr_orders_col.find_one({
        "user_id": user_id,
        "uploaded_qr_ids": file_unique_id
    })
    return existing is not None


def has_pending_qr_order(user_id: int) -> bool:
    """Check if the user has an active, uncompleted QR order."""
    count = qr_orders_col.count_documents({
        "user_id": user_id,
        "status": {"$in": ["awaiting_qr", "qr_uploaded", "reupload"]}
    })
    return count > 0


def refund_stock(product_id: str, qty: int, is_numerical: bool, items: list[str]) -> None:
    """Refund stock back to the inventory when an order is rejected."""
    if not product_id:
        return
        
    from bson import ObjectId
    try:
        pid = ObjectId(product_id)
    except Exception:
        return

    if is_numerical:
        products_col.update_one(
            {"_id": pid},
            {"$inc": {"numerical_stock": qty}}
        )
    else:
        if not items:
            return
        stock_col.update_many(
            {"product_id": pid, "content": {"$in": items}},
            {"$set": {"is_sold": False, "sold_to": None, "sold_at": None}}
        )

# ╔══════════════════════════════════════════════════════════════════════╗
# ║  CLEANUP helpers                                                    ║
# ╚══════════════════════════════════════════════════════════════════════╝

cleanup_tasks_col = db["cleanup_tasks"]

def ensure_cleanup_indexes() -> None:
    cleanup_tasks_col.create_index([("delete_at", ASCENDING)])

# Call this to ensure the index exists
ensure_cleanup_indexes()

def schedule_message_cleanup(chat_id: int, message_id: int, hours: int = 24) -> None:
    """Schedule a message to be deleted after a certain number of hours."""
    from datetime import timedelta
    delete_at = datetime.now(timezone.utc) + timedelta(hours=hours)
    doc = {
        "chat_id": chat_id,
        "message_id": message_id,
        "delete_at": delete_at
    }
    cleanup_tasks_col.insert_one(doc)

def get_expired_cleanup_tasks() -> list[dict]:
    """Retrieve messages that are scheduled to be deleted and have expired."""
    now = datetime.now(timezone.utc)
    return list(cleanup_tasks_col.find({"delete_at": {"$lte": now}}))

def remove_cleanup_task(task_id: str) -> None:
    """Remove a cleanup task from the database after it has been processed."""
    from bson import ObjectId
    cleanup_tasks_col.delete_one({"_id": ObjectId(task_id)})
